#!/data/data/com.termux/files/usr/bin/bash
# Lattice Law v1.0 — one-shot push from Termux
# Usage: unzip lattice_v1.zip -d ~/lattice_v1 && cd ~/lattice_v1 && bash push.sh
set -e
REPO=~/hypercubeheartbeat
if [ ! -d "$REPO/.git" ]; then
  gh repo clone ProCityHub/hypercubeheartbeat "$REPO"
fi
cp README.md PREREGISTRATION.md RETRACTIONS.md CITATION.cff preregistration_test.py lattice_bridge.py "$REPO/"
cd "$REPO"
python3 lattice_bridge.py > /dev/null && echo "bridge runs against repo code: OK"
git add README.md PREREGISTRATION.md RETRACTIONS.md CITATION.cff preregistration_test.py lattice_bridge.py
git commit -m "Lattice Law v1.0: unified bridge, pre-registration, retractions, citation"
git push
echo "pushed — pre-registration clock started: $(date)"
