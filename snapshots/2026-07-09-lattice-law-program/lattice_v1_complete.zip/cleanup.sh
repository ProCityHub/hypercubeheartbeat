#!/data/data/com.termux/files/usr/bin/bash
# ProCityHub COMPLETE CLEANUP — v1.0
# Order of operations: BACK UP EVERYTHING PRIVATELY FIRST, remove public
# exposure second, publish the honest work third. Nothing is lost — every
# repo is mirrored to a private copy before its public version is touched.
#
# Requires: gh auth login  (with 'repo' and 'delete_repo' scopes:
#           gh auth refresh -h github.com -s delete_repo)
set -e
ORG=ProCityHub
WORK=~/procity_cleanup && mkdir -p $WORK && cd $WORK

echo "== STEP 1: Private backups of every fork (nothing deleted yet) =="
FORKS="GARVIS Memori open-interpreter arc-prize-2024 ARC-AGI adk-python \
kaggle-api milvus grok-1 gemini-cli root llama-models llama-cookbook \
PurpleLlama IDOL arcagi SigilForge tarik_10man_ranks"
for r in $FORKS; do
  echo "-- backing up $r"
  git clone --mirror "https://github.com/$ORG/$r.git" "$r.git"
  gh repo create "$ORG/${r}-vault" --private -y 2>/dev/null || true
  cd "$r.git" && git push --mirror "https://github.com/$ORG/${r}-vault.git" && cd ..
done
echo "All 18 forks mirrored to private -vault copies. Verify before Step 3:"
echo "  gh repo list $ORG --visibility private"

echo "== STEP 2: Privatize the source repos with exposure =="
gh repo edit $ORG/AGI --visibility private --accept-visibility-change-consequences
gh repo edit $ORG/THUNDERBIRD --visibility private --accept-visibility-change-consequences
gh repo edit $ORG/AGI-POWER --visibility private --accept-visibility-change-consequences

echo "== STEP 3: Delete the PUBLIC forks (private vaults keep everything) =="
echo "GARVIS public fork contains your legal name in reasoning_chain.md history."
read -p "Backups verified? Type DELETE to remove the 18 public forks: " CONFIRM
if [ "$CONFIRM" = "DELETE" ]; then
  for r in $FORKS; do gh repo delete "$ORG/$r" --yes; done
  echo "Public forks removed. Legal-name exposure is closed."
else
  echo "Skipped deletion. Run again when ready. Name remains public until then."
fi

echo "== STEP 4: Publish the honest work =="
if [ -d ~/lattice_v1 ]; then
  cd ~/lattice_v1 && bash push.sh
else
  echo "lattice_v1 bundle not found — unzip lattice_v1.zip to ~/lattice_v1 and run push.sh"
fi
gh repo edit $ORG/hypercubeheartbeat \
  --description "Deterministic LIF cognitive architecture scored by O·A^(1/phi)·B^(1/phi^2) — pre-registered, retractions public"

echo "== STEP 5 (manual, 30 seconds) =="
echo "GitHub → Settings → Public profile: remove the phone number from your bio."
echo
echo "END STATE: one public repo. Runnable, pre-registered, cited, honest."
